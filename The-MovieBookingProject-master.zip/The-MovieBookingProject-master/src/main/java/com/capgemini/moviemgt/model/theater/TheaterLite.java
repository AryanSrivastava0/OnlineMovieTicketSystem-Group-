/**
 * 
 */
package com.capgemini.moviemgt.model.theater;

/**
 * @author krishna
 *
 */
public interface TheaterLite {

	int getTheaterId() ;
	String getTheaterName() ; 
}
