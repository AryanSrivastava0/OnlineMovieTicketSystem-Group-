package com.capgemini.moviemgt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/**
 * @author krishna
 *
 */
@SpringBootApplication
public class OnlineMovieTicketSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineMovieTicketSystemApplication.class, args);
	}

}
