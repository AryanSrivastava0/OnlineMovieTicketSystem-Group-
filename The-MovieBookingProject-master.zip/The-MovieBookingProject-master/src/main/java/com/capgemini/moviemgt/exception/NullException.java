/**
 * 
 */
package com.capgemini.moviemgt.exception;

/**
 * @author krishna
 *
 */
@SuppressWarnings("serial")
public class NullException extends RuntimeException{

	public NullException(String msg) {
		super(msg) ;
	}
}
