package com.capgemini.moviemgt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineMovieTicketSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
