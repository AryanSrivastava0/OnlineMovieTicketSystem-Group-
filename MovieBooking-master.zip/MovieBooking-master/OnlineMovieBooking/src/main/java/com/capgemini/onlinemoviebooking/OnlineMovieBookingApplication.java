package com.capgemini.onlinemoviebooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineMovieBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineMovieBookingApplication.class, args);
	}

}
