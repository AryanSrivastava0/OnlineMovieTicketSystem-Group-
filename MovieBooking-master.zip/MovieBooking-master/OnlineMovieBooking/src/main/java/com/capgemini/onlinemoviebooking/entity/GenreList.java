package com.capgemini.onlinemoviebooking.entity;

public enum GenreList {
	
     Fantasy,Thriller,SciFi,Action,Periodic,Comedy,Drama,Crime,Animation,Fiction,Horror,Adventure,Romantic,None
}
